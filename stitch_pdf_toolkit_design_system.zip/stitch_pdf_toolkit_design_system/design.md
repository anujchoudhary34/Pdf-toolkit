# DESIGN.md — PDF Toolkit (Android Flutter Specification)

## 1. Executive Summary & Brand Principles
- **Product Name:** PDF Toolkit
- **Platform Priority:** Android-first (Material 3 guidelines, 48dp touch targets, back gesture awareness, system inset safe areas).
- **Core Value Proposition:** Fast, completely local / offline, privacy-first PDF utility suite with zero server telemetry or document uploads.
- **Visual Personality:** Utilitarian, crisp, trustworthy, high-contrast, distraction-free.

---

## 2. Design Tokens & Color Palette

### 2.1 Color Tokens (Light & Dark Mode)

| Token Name | Light Mode (HEX) | Dark Mode (HEX) | Usage / Semantics |
| :--- | :--- | :--- | :--- |
| `color-primary` | `#1A73E8` | `#8AB4F8` | Primary FABs, active indicators, brand highlights |
| `color-on-primary` | `#FFFFFF` | `#041E49` | Text/icons on primary button |
| `color-primary-container` | `#E8F0FE` | `#174EA6` | Pill badges, subtle active tool highlights |
| `color-on-primary-container` | `#041E49` | `#D2E3FC` | Text inside primary container tags |
| `color-accent-teal` | `#0D9488` | `#2DD4BF` | Secondary tool accents, compression stats, offline badges |
| `color-surface` | `#F8FAFD` | `#0F172A` | Scaffold background |
| `color-surface-container` | `#FFFFFF` | `#1E293B` | Card surfaces, bottom sheets, app bar |
| `color-surface-container-high` | `#F1F5F9` | `#334155` | Elevated chips, selected state backgrounds |
| `color-outline` | `#E2E8F0` | `#334155` | Dividers, card borders, drag-and-drop zones |
| `color-text-primary` | `#0F172A` | `#F8FAFC` | Headings, document titles, primary labels |
| `color-text-secondary` | `#475569` | `#94A3B8` | Subtitles, file metadata (size, page count, date) |
| `color-text-tertiary` | `#94A3B8` | `#64748B` | Disabled hints, input placeholders |
| `color-success` | `#10B981` | `#34D399` | Success badges, 100% progress, saved status |
| `color-warning` | `#F59E0B` | `#FBBF24` | Overwrite warnings, heavy compression quality alerts |
| `color-error` | `#EF4444` | `#F87171` | Corrupt file alerts, delete action, failed operations |

---

## 3. Typography Hierarchy

Target System Font: `Roboto` / `Inter` / System Default Sans

| Text Style | Size | Weight | Line Height | Letter Spacing | Usage |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `Headline Large` | 28sp | Bold (700) | 36sp | 0 | Screen top headers (Home, Result headings) |
| `Headline Medium` | 22sp | SemiBold (600) | 28sp | 0 | Tool modal titles, bottom sheet headers |
| `Title Large` | 18sp | SemiBold (600) | 24sp | 0.15 | Card titles, tool section headers |
| `Title Medium` | 16sp | Medium (500) | 22sp | 0.15 | File list item names, dialog titles |
| `Body Large` | 15sp | Regular (400) | 22sp | 0.25 | Explanatory copy, empty state descriptions |
| `Body Medium` | 13sp | Regular (400) | 18sp | 0.25 | File metadata (e.g., "12.4 MB • 32 Pages") |
| `Label Large` | 14sp | SemiBold (600) | 20sp | 0.1 | Primary button text, chip labels |
| `Label Small` | 11sp | Medium (500) | 16sp | 0.5 | Page numbering badges, status tags |

---

## 4. Spacing & Grid System

- **Base Unit:** `4dp / 8dp` grid
- **Screen Margins:** Horizontal padding = `16dp` (standard phone viewport)
- **Card Padding:** `16dp` inner padding; `12dp` between compact list elements
- **Inter-Section Gaps:** `24dp`
- **Bottom Navigation Height:** `64dp` + System Navigation bar padding
- **Top App Bar Height:** `56dp` (standard) / `96dp` (expanded hero)
- **Minimum Touch Target:** `48dp x 48dp` on all interactive buttons, icon buttons, and checkboxes.
- **Corner Radii:**
  - Standard Cards: `16dp`
  - Bottom Sheets: Top corners `24dp`
  - Buttons / Chips: `12dp` or `full pill (999dp)`
  - Page Thumbnails: `8dp`

---

## 5. Screen Structure & Feature Specifications

### Screen 1: Home (Tools Dashboard)
- **Top Bar:** Brand logo icon, "PDF Toolkit", Offline badge ("Local & Secure", Shield icon), Quick search/filter.
- **Quick Action Carousel / Highlights:**
  - Large Quick Cards: "Images to PDF", "Merge Files", "Compress".
- **Categorized Tool Grid (2 columns):**
  - *Convert:* Images → PDF, PDF → Images.
  - *Organize:* Merge PDF, Split PDF, Manage / Reorder Pages.
  - *Optimize:* Compress PDF.
- **Recent Files Quick Preview:** Horizontal scroll of last 3 edited files with quick resume actions.
- **Bottom Bar:** [Tools (Active), Recents, Settings].

### Screen 2: Recent Files
- **Header:** "Recent Files", Search bar, Sort button (By Date, Name, Size), Storage usage gauge ("Offline App Cache: 42 MB").
- **List View Items:** File icon with PDF thumbnail preview, filename, date timestamp, file size, page count, and 3-dots action menu (Share, Open In, Save to Downloads, Delete).
- **Batch Actions:** Long-press enters multi-selection mode with bottom action bar (Delete, Batch Share, Merge Selected).

### Screen 3: Settings
- **Privacy Assurance Card:** "100% Offline Processing. Your files never leave this device."
- **Preferences:**
  - Theme: Light / Dark / System Default.
  - Default Output Directory: `/Documents/PDFToolkit/`.
  - Default Image Conversion Quality: High (300 DPI) / Standard (150 DPI) / Web (72 DPI).
  - Page Numbering Overlay default toggle.
  - Clear Cached Temp Files button with space reclaimed indicator.
  - About, Open Source Licenses, Version 1.0.0.

### Screen 4: Images → PDF
- **Workflow:** Select images from gallery → reorder via drag handle grid → set page orientation (Auto / Portrait / Landscape) and margins (None / Small / Wide) → tap "Generate PDF".
- **Batch Controls:** Add more images FAB, "Select All", "Clear All".

### Screen 5: Merge PDF
- **Workflow:** Add multiple PDF files → vertical list with drag-reorder handles → file preview cards with page count badges → target merged file naming input → "Merge PDFs" sticky action button.

### Screen 6: Split PDF
- **Workflow:** Select source PDF → preview pages → pick split mode:
  - *Mode A: By Page Range* (e.g. "1-5, 8, 11-14").
  - *Mode B: Extract All Pages* into separate PDFs.
  - *Mode C: Split Every N Pages*.
- **Live Output Calculation:** "Will generate 3 output files".

### Screen 7: PDF → Images
- **Workflow:** Select source PDF → select target pages (All / Selected) → output format selector (JPEG / PNG) → output quality slider (DPI) → "Extract Images" button.

### Screen 8: Compress PDF
- **Workflow:** Select source PDF (shows original size: e.g. 14.8 MB) → compression tier selector:
  - *Extreme Compression:* Low quality, smallest size (~70% reduction).
  - *Recommended Compression:* Balanced standard quality (~45% reduction).
  - *Low Compression:* High print quality (~15% reduction).
- Estimate preview badge: "Est. new size: ~8.1 MB".

### Screen 9: Manage PDF Pages
- **Workflow:** Reorderable 3-column page thumbnail grid.
- **Page Actions:** Rotate 90° clockwise, duplicate page, delete page, insert blank page, extract selected.
- **Numbering:** Dynamic page badges (`1`, `2`, `3`...) updating instantly upon drag.

### Screen 10: File Selection / Import States
- Empty drop/tap zone with dotted outline and "Browse Files" button.
- Multi-file staging list with thumbnail, file size, load progress check, remove icon.

### Screen 11: PDF / Page Preview States
- High-fidelity single-page and dual-page viewer mode.
- Zoom gestures, page indicator floating pill ("Page 4 of 24"), navigation thumbnail strip at the bottom.

### Screen 12: Processing / Progress State
- Modal/Screen overlay with background blur.
- Dual progress: Circular percentage indicator (`68%`), descriptive phase step ("Downsampling images... Page 14 of 22"), animated local processing icon, and "Cancel Operation" safe button.

### Screen 13: Success State
- Centered celebratory emerald checkmark card.
- Output summary: File name, final size, size saved delta (e.g. "-6.7 MB (-48%)").
- Primary Action: "Open File", Secondary: "Share", "Save to Device", "Back to Home".

### Screen 14: Error & Empty States
- **Empty State:** Clean vector illustration, friendly headline ("No recent files yet"), immediate call-to-action button ("Start with a PDF Tool").
- **Error State:** Subtle soft-red container, clear error diagnostic ("Unable to decrypt PDF. File is password protected"), and actionable button ("Enter Password" or "Choose Another File").

---

## 6. Offline & Privacy-First Architecture Decisions
1. **Zero External Network Dependencies:** No cloud conversions, analytics tracking, or remote font lookups.
2. **Explicit Temp File Lifecycle:** All intermediate conversion frames are stored in app-scoped cache and purged upon workflow completion or cancellation.
3. **Scoped Storage Compliance:** Direct integration with Android Storage Access Framework (SAF) for zero unnecessary device-wide storage permissions.

---

## 7. Next AI Implementation Checklist (Flutter)
- [ ] Material 3 `ThemeData` with dynamic Light/Dark color schemes matching defined tokens.
- [ ] Implement `ReorderableListView` / `ReorderableGridView` for page and file sequencing.
- [ ] Utilize local-only libraries (e.g., `pdf`, `printing`, `image`, `path_provider`).
- [ ] Maintain strict 48dp touch targets on all interactive icon buttons.
- [ ] Ensure back button safely pops modal sheets or confirms cancellation if processing is active.
