---
name: Material Document Engine
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#414754'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#727785'
  outline-variant: '#c1c6d6'
  surface-tint: '#005bc0'
  primary: '#005bbf'
  on-primary: '#ffffff'
  primary-container: '#1a73e8'
  on-primary-container: '#ffffff'
  inverse-primary: '#adc7ff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#515f74'
  on-tertiary: '#ffffff'
  tertiary-container: '#6a788d'
  on-tertiary-container: '#000510'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc7ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#d5e3fc'
  tertiary-fixed-dim: '#b9c7df'
  on-tertiary-fixed: '#0d1c2e'
  on-tertiary-fixed-variant: '#3a485b'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a high-performance, precision-grade utility environment tailored for Android-first document workflows. It communicates immediate trust, mathematical exactness, and complete privacy: all document processing is visually affirmed as offline, sovereign, and local to the device. 

The aesthetic is Modern Utility anchored in Material 3 principles. It avoids ornamental decoration in favor of crisp content hierarchy, instant cognitive clarity, and tactile physical feedback. The interface balances technical capability (merging, signing, compressing, OCR) with approachable ergonomics. Surfaces feel disciplined, structured, and resilient, framing document sheets cleanly against functional slate canvases without distracting from the user's files.

## Colors

The system uses a balanced color model designed to accommodate both daylit outdoor scanning tasks and power-efficient OLED viewing:

- **Primary (`#1A73E8`)**: Tech Indigo / Cobalt Blue acts as the decisive interaction anchor. Used for primary floating actions, key toggles, active tab selections, and linear processing indicators.
- **Secondary / Accent (`#0D9488`)**: Deep Teal provides positive verification, offline badge signaling, security indicators, and secondary tool highlights.
- **Tertiary (`#475569`)**: Balanced Slate for secondary content anchors, tool headers, and contextual badges.
- **Neutrals**:
  - Light Canvas: Off-white canvas (`#F8FAFC`) with crisp pure-white surface tiers (`#FFFFFF`) to visually lift document previews. Primary typography uses deep slate (`#0F172A`).
  - Dark Canvas: OLED-optimized deep charcoal (`#0B0F17`) foundation rising to structural surface containers (`#1E293B`) and high-contrast pale slate text (`#F1F5F9`).
- **Semantic Feedback**:
  - Success: `#10B981` (Emerald) for finished renders, valid signatures, and successful exports.
  - Warning: `#F59E0B` (Amber) for large file alerts, lossy compression limits, or destructive page removals.
  - Error: `#EF4444` (Rose) for corrupted files, failed renders, and password errors.

## Typography

Typography relies on `Inter` across all functional roles to guarantee exceptional legibility at dense information scales (e.g., page counters, file sizes, metadata flags).

- **Headlines**: Weighted at semi-bold (600) with tightened letter tracking to deliver authoritative, clean titles in top app bars and modal bottom sheets without overflowing across narrow viewports.
- **Body**: Uses regular (400) weight with relaxed line spacing (1.5) to keep file paths, conversion explanations, and license terms readable.
- **Labels & Numbers**: Employ medium (500) and semi-bold (600) weights with tabular numeric settings enabled where applicable, ensuring stable alignment in multi-page reordering grids, byte-size counters, and conversion percentage displays.

## Layout & Spacing

The layout is built upon an 8dp baseline grid (with a strict 4dp micro-step for icons and badges). 

- **Touch Ergonomics**: All interactive regions (buttons, list entries, thumbnail check boxes, menu triggers) enforce an absolute minimum target of 48dp × 48dp, even if the visible element itself is smaller.
- **Canvas Adaptive Model**:
  - **Mobile (<600dp)**: Single column with a 4-column sub-grid for tools, 16dp edge margins, and bottom-anchored touch targets within thumb reach. Thumbnails display in a 2-up or 3-up fluid reorderable matrix.
  - **Tablet (600dp–840dp)**: 8-column layout with 24dp margins; NavigationBar shifts cleanly into a NavigationRail on the left, opening up vertical room for side-by-side split document inspection.
  - **Desktop / Foldable Expanded (>840dp)**: 12-column grid with dynamic max-width constraints (1200dp max content container) centered, enabling master-detail views (tools sidebar + document preview canvas).

## Elevation & Depth

Visual hierarchy uses Material 3 tonal elevation accompanied by soft ambient shadows to express functional stratification:

- **Level 0 (Flat / Canvas)**: `0dp` elevation. The primary canvas backdrop (`#F8FAFC` light / `#0B0F17` dark).
- **Level 1 (Cards & File Tiles)**: `1dp` elevation. In light mode, defined by a 1px subtle outline border (`#E2E8F0`) paired with a faint ambient drop: `0px 1px 3px rgba(15, 23, 42, 0.05)`. In dark mode, achieved through a lightened slate surface tint (`#1E293B`) without bright edge lines.
- **Level 2 (Active Sheets & Navigation Bar)**: `3dp` elevation. Used for persistent bottom navigation bars and floating tool bars: `0px 4px 12px rgba(15, 23, 42, 0.08)`.
- **Level 3 (Floating Action Button & Modals)**: `6dp` elevation. Reserved for primary FABs and modal bottom sheet containers: `0px 8px 24px rgba(15, 23, 42, 0.12)`.
- **Dragged Items (Thumbnail Grid Reorder)**: Temporary boost to `8dp` elevation with a 1.04x scale factor to give physical feedback when lifting pages to resequence.

## Shapes

The design system standardizes on a roundedness level of `2`, producing friendly yet structural corners:

- Standard structural components (cards, dialog surfaces, modal bottom sheet tops) employ `1rem` (16dp) or `1.25rem` (20dp) corner radiuses.
- Interactive controls (action buttons, text input fields) feature `0.75rem` (12dp) corners.
- Status chips, page counter badges, and FABs adopt fully pill-shaped geometries (9999px) to contrast against rectilinear document pages.
- Document preview thumbnails maintain a tight `0.375rem` (6dp) corner radius with a subtle border to replicate genuine paper sheets.

## Components

### TopAppBar & NavigationBar
- **TopAppBar**: Material 3 small and large collapsibles. Background matches surface level 0 when idle, seamlessly transitioning to surface level 2 on scroll with an integrated divider. Title is bold and left-aligned; trailing actions host overflow options, search, and privacy state icons (e.g., local shield badge).
- **NavigationBar**: 80dp tall bottom bar holding 3-4 destinations (Tools, Recent Files, Settings). Inactive icons are high-contrast slate outlines; active tabs sit inside a pill-shaped indicator tinted with primary surface tint (`#E0EDFF` light / `#1E3A8A` dark).

### Action Buttons & FABs
- **Filled Button**: Primary interactions (e.g., "Merge PDFs", "Apply Signature"). 48dp height, 12dp radius, tech indigo fill with pure white label.
- **Outlined / Tonal Buttons**: Secondary interactions (e.g., "Add More Pages"). 1.5px slate border (`#CBD5E1`), 12dp radius, no shadow.
- **Floating Action Button (FAB)**: Primary creation or import action. 56dp squircle (or 48dp extended pill with icon + label), `#1A73E8` background, providing distinct elevation (Level 3).

### Reorderable Page Thumbnail Grid
- Renders page representations at a fixed 1:1.414 (A4) aspect ratio inside a flexible column grid.
- Each thumbnail is framed by a 1px border (`#E2E8F0`).
- Bottom-right corner anchors a high-contrast circular page index badge (`#0F172A` background with white text).
- Top-right corner provides a 48dp accessible tap target containing a checkbox or quick-delete button.
- Drag-and-drop state applies a distinct teal border (`#0D9488`), lifted elevation, and subtle haptic trigger.

### Bottom Sheets & Tool Configurations
- Anchored to the viewport bottom with a 24dp top-corner radius.
- Includes a prominent 32dp × 4dp drag handle centered at the top.
- Houses modular controls for tool operations (compression sliders, encryption toggles, page orientation switchers).

### Progress & Processing Indicators
- **Linear Progress Indicator**: 6dp thick rounded bar positioned immediately beneath the TopAppBar during file operations, using Tech Indigo for elapsed track and `#E2E8F0` for background.
- **Circular Progress**: Centered percentage counter surrounded by a 4dp stroke spinner during compute-heavy tasks like OCR or local compression.

### State Cards & Feedback
- **Success State**: Card bordered in `#10B981` featuring an animated emerald checkmark, resulting file size comparison, and immediate "Open File" and "Share" buttons.
- **Empty States**: Centered technical line illustrations paired with a concise Title-MD, supporting body text explaining offline privacy, and an immediate primary file-picker action.